var socket = io.connect();

$(document).ready(function(){
    var name = prompt("What is your name?");

    socket.emit("userCreate", {name: name});

    $("#submit").click(function(){
        var post = $("#msg").val();
        $("#msg").val("");
        socket.emit("userPost", {post: post});
    });

    socket.on("updateMsgs", function(data){
        console.log(data.msgs);
        $("#chat").html("<p><strong>" + data.msgs[0][1] + ":</strong> " + data.msgs[0][0] + "</p>");
        for(let i=1; i<data.msgs.length; i++){
            $("#chat").append("<p><strong>" + data.msgs[i][1] + ":</strong> " + data.msgs[i][0] + "</p>");
        }
    })
    
});