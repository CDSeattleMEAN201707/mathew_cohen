var express = require("express");
var path = require("path");
var app = express();
var bodyParser = require('body-parser');
var mongoose = require('mongoose');
var Schema = mongoose.Schema;

mongoose.connect('mongodb://localhost/msgboard', {useMongoClient: true});

app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static(path.join(__dirname + "/static")));

app.set('views', path.join(__dirname + '/views'));
app.set('view engine', 'ejs');

// Message Schema
var MsgSchema = new mongoose.Schema({
    name: {type: String, required: true, minlength: 4},
    msg: {type: String, required: true},
    comments: [{type: Schema.Types.ObjectId, ref: 'Comment'}]
}, {timestamps: true})
var Msg = mongoose.model('Msg', MsgSchema);

// Comment Schema
var CommentSchema = new mongoose.Schema({
    _msg: {type: Schema.Types.ObjectId, ref: 'Msg'},
    name: {type: String, required: true, minlength: 4},
    comment: {type: String, required: true}
}, {timestamps: true})
var Comment = mongoose.model('Comment', CommentSchema);

app.get('/', function(req, res){
    Msg.find({}).populate('comments').exec(function(err, msgs){
        if(err){
            console.log("not working");
            res.render('index', {errors: msgs.errors});
        }else{
            console.log("working");
            res.render('index', {msgs: msgs});
        }
    })
});

app.post('/postMsg', function (req, res){
    var msg = new Msg({name: req.body.name, msg: req.body.msg});
    console.log(msg);
    msg.save(function(err){
        if(err){
            console.log("Error adding a msg");
            res.render('index', {errors: msg.errors});
        }else{
            console.log("woot.");
            res.redirect('/');
        }
    })
})
app.post('/postComment', function (req, res){
    var comment = new Comment({name: req.body.name, comment: req.body.comment});
    comment._msg = req.body.id;
    comment.save(function(err){
        Msg.update({_id: req.body.id}, {$push: {comments: comment}}, function(err, msg){
            if(err){
                console.log("Error adding a comment");
                res.render('index', {errors: msg.errors});
            }else{
                console.log("woot.");
                res.redirect('/');
            }
        })  
    })
})

var server = app.listen(8000, function(){});