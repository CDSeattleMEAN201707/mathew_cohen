// this snippet should be in: >ProjectDir/server/controllers/CONTROLLER_NAME.js
var mongoose = require('mongoose');
var Person = mongoose.model('Person');
module.exports = {
    index: function(req, res){
        Person.find({}, function(err, people){
            res.json(people);
        })
    },
    addNew: function(req, res){
        var person = new Person({
            name: req.params.name
        })
        person.save(function(err){
            if(err){
                console.log('Error saving during create');
                res.redirect('/');
            }else{
                res.redirect('/');
            }
        })
    },
    info: function(req, res){
        Person.find({name: req.params.name}, function(err, person){
            if(err){
                console.log("Coudlnt' Find person");
                res.redirect('/');
            }else{
                res.json(person);
            }
        })
    },
    remove: function(req, res){
        Person.remove({name: req.params.name}, function(err){
            if(err){
                console.log('Error saving during create');
                res.redirect('/');
            }else{
                res.redirect('/');
            }
        })
    }
}
