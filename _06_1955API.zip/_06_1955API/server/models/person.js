// this snippet should be in: >ProjectDir/server/models/MODEL_NAME.js
var mongoose = require('mongoose');
var PersonSchema = new mongoose.Schema({
    name: {type: String, required: true, minlength: 4}
});
var Person = mongoose.model('Person', PersonSchema);
