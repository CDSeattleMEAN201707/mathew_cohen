// this snippet should be in: >ProjectDir/server/config/mongoose.js
// This file connects to the database AND loads all of the models in the models path

var mongoose = require('mongoose');
var fs = require('fs');
var path = require('path');

mongoose.Promise = global.Promise
mongoose.connect('mongodb://localhost/1955', {useMongoClient: true});

var models_path = path.join(__dirname, './../models');

fs.readdirSync(models_path).forEach(function(file){
    if(file.indexOf('.js') >= 0){
        require(models_path + '/' + file);
    }
});
