// this snippet should be in: >ProjectDir/server/config/routes.js

var people = require('../controllers/people.js');
module.exports = function(app){
    app.get('/', function(req, res){
        people.index(req, res);
    })
    app.get('/new/:name/', function(req, res){
        people.addNew(req, res);
    })
    app.get('/:name', function(req, res){
        people.info(req, res);
    })
    app.get('/remove/:name', function(req, res){
        people.remove(req, res);
    })
}
