// this snippet should be in: >ProjectDir/server/models/user.js
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const uniqueValidator = require('mongoose-unique-validator');
const UserSchema = new mongoose.Schema({
    first: {
        type: String,
        required: [true, 'First name should be at least 2 letters'],
        minlength: [2, 'First name should be at least 2 letters'],
        trim: true,
        validate: [{
            validator: (txt) => {
            return /^(?=.*[A-Za-z])/.test(txt);
            },
            message: 'First name should only contain letters'
        }]
    },
    last: {
        type: String,
        required: [true, 'Last name should be at least 2 letters'],
        minlength: [2, 'Last name should be at least 2 letters'],
        trim: true,
        validate: [{
            validator: (txt) => {
                return /^(?=.*[A-Za-z])/.test(txt);
            },
            message: 'Last name should only contain letters'
        }]
    },
    email: {
        type: String,
        required: [true, 'Email address required'],
        unique: true,
        trim: true,
        validate: [{
            validator: (txt) => {
                return /^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$/.test(txt);
            },
            message: 'That is not a valid email address.'
        }]
    },
    pass: {
        type: String,
        required: [true, 'No password, no love.'],
        minlength: [8, 'Password must be a minimum of 8 characters']
    },
    bday: {
        type: Date,
        required: [true, 'No birthday, huh? Too bad... you are just gonna have to sit there and wait to be born.'],
        validate: [{
            validator: (bday) => {
                return bday < Date.now();
            },
            message: 'No. Just, no. If you have not been born yet, you are not doing this right.'
        }]
    }
}, {timestamps: true});

UserSchema.plugin(uniqueValidator, {message: 'That email address is already registered, please login or register another email address.'});

UserSchema.pre('save', function(finished) {
    this.email = this.email;
    this.pass = bcrypt.hashSync(this.pass, bcrypt.genSaltSync(8));
    finished();
})

mongoose.model('User', UserSchema);