// this snippet should be in: >ProjectDir/server/controllers/users.js
const mongoose = require('mongoose');
const User = mongoose.model('User');
const bcrypt = require('bcrypt');
mongoose.Promise = global.Promise;

module.exports = {
    register: function(req, res){
        if (req.body.pass != req.body.confirm){
            res.render('index', {error: 'Typed passwords do not match.'})
        }else{
            let user = new User({
                first: req.body.first,
                last: req.body.last,
                email: req.body.email,
                pass: req.body.pass,
                bday: req.body.bday
            });
            let promise = user.save();
            promise.then(function(result){
                res.redirect('/success');
            }).catch(function(err){
                res.render('index', {errors: err})
            })
        }
    },
    login: function(req, res){
        if (req.body.email == ""){
            res.render('index', {error: 'That email address is not valid.'});
        }else{
            User.findOne({email: req.body.email}, function(err, user){
                if (err){
                    res.render('index', {errors: err});
                }else{
                    if (user == null){
                        res.render('index', {error: 'That email address is not registered. You should do that instead.'});
                    }else if (!bcrypt.compareSync(req.body.pass, user.pass)){
                        res.render('index', {error: 'Incorrect Password.'});
                    }else{
                        res.redirect('/success');
                    }
                }
            })
        }
    }
}
