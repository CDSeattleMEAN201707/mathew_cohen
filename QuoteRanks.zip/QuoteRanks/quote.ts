export class Quote {
    public quote: string = "";
    public author: string = "";
    public votes: number = 1;
}
