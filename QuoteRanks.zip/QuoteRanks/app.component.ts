import { Component } from '@angular/core';
import { Quote } from './quote';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  q = new Quote;
  quotesArr = [];

  onSubmit(){
    this.quotesArr.push(this.q);
    this.q = new Quote;
  }
  uVote(item){
    this.quotesArr[item].votes += 1;
  }
  dVote(item){
    this.quotesArr[item].votes -= 1;
  }
  del(item){
    this.quotesArr.splice(item, 1);
  }
}
