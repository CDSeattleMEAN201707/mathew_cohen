import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-retrobarcode',
  templateUrl: './retrobarcode.component.html',
  styleUrls: ['./retrobarcode.component.css']
})
export class RetrobarcodeComponent implements OnInit {
    hexstr: Array<string>;

    colorArray: Array<string> = [];

    constructor() { 
        this.hexstr = ["Purple","Red","Aqua","Aquamarine","Brown","Green","Bisque","Blue","BurlyWood","CadetBlue"];
        for(let i=0; i<10; i++){
            this.colorArray[i] = this.hexstr[Math.floor(Math.random() * (this.hexstr.length-1))];
        }
    }
  
    ngOnInit() {
        
    }

}
