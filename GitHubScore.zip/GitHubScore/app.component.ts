import { Component } from '@angular/core';
import { HttpService } from './service/http.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  user = {uname: ""};
  GHInfo: {};

  constructor(private _httpService: HttpService){}
  
  getScore(){
    console.log(this.user.uname);
    this._httpService.retrieveGitInfo(this.user.uname).then(GHInfo => {this.GHInfo = GHInfo}).catch(err=>{console.log(err)});
  }
}
