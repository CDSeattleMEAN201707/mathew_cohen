export class User {
    constructor(
        public first: string = "",
        public last: string = "",
        public email: string = "",
        public pass: string = "",
        public confirm: string = "",
        public street: string = "",
        public unit?: string,
        public city: string = "",
        public state: string = "",
        public zip: number = null,
        public lucky: boolean = null,
        public created_at: Date = new Date(),
        public updated_at: Date = new Date()
    ){}
}
