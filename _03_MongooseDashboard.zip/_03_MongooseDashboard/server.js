var express = require("express");
var path = require("path");
var app = express();
var bodyParser = require('body-parser');
var mongoose = require('mongoose');

mongoose.connect('mongodb://localhost/wolves', {useMongoClient: true});

app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static(path.join(__dirname + "/static")));

app.set('views', path.join(__dirname + '/views'));
app.set('view engine', 'ejs');

// SCHEMA STUFF
var WolfSchema = new mongoose.Schema({
    name: {type: String, required: true},
    age: {type: Number, required: true},
    color: {type: String, required: true}
})
mongoose.model('Wolf', WolfSchema);
var Wolf = mongoose.model('Wolf');

// index page, show all wolves in db
app.get('/', function(req, res){
    Wolf.find({}, function(err, wolves){
        if(err){
            console.log("Something is wrong 0");
            res.render('index', {errors: wolves.errors});
        }else{
            res.render('index', {wolves: wolves});
        }
    })
});

// display form for adding new wolf
app.get('/wolves/new', function(req, res){
    res.render('form');
});

// display info about one wolf
app.get('/wolves/:id', function(req, res){
    Wolf.findOne({_id: req.params.id}, function(err, wolf){
        if(err){
            console.log("Something is wrong 1");
            res.render('index', {errors: wolf.errors});
        }else{
            res.render('info', {wolf: wolf});
        }
    })
});

// post for adding a new wolf
app.post('/wolves', function (req, res){
    var wolf = new Wolf({name: req.body.name, age: req.body.age, color: req.body.color});
    wolf.save(function(err){
        if(err){
            console.log("Error adding a wolf");
            res.render('form', {errors: wolf.errors});
        }else{
            console.log("woot.");
            res.redirect('/');
        }
    })
});

// get for editing a wolf
app.get('/wolves/edit/:id', function(req,res){
    Wolf.findOne({_id: req.params.id}, function(err, wolf){
        if(err){
            console.log("Something is wrong 2");
            res.render('info', {errors: wolf.errors});
        }else{
            res.render('edit', {wolf: wolf});
        }
    })
})
// post for editing a wolf
app.post('/wolves/edit', function (req, res){
    Wolf.update({_id: req.body.id}, {$set: {name: req.body.name, age: req.body.age, color: req.body.color}}, function(err){
        if(err){
            console.log("Something is wrong 3");
            res.render('edit', {errors: wolf.errors});
        }else{
            console.log("Update worked.");
            res.redirect('/');
        }
    })
});

// post for deleting wolves
app.get('/wolves/delete/:id', function(req, res){
    Wolf.remove({_id: req.params.id}, function(err, wolf){
        if(err){
            console.log("Something is wrong 43");
            res.render('edit', {errors: wolf.errors});
        }else{
            console.log("Delete worked.");
            res.redirect('/');
        }
    })
});

var server = app.listen(8000, function(){
    console.log("Listening on port 8000");
});